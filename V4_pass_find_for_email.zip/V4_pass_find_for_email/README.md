How to run the program https://www.youtube.com/watch?v=pFYcAOsNyvs

run in cmd: python "C:/Users/your username/Desktop/V2_pass_find_for_1_email/main.py"

IMPORTANT (the scrypt will not work without this):
to install the libraries to work go to cmd and run 'pip install colorama' without the ''